#!/usr/bin/env python

from math import pi
r = 3
h = 5
cylVol = pi * r**2 * h

print(cylVol)