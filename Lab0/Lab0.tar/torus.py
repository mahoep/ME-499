#!/usr/bin/env python

from math import pi

R = 3.5
r = 0.5

torusVol = (pi * r**2) * (2 * pi * R)
print(torusVol)